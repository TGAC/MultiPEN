#!/bin/sh
# script to test the deployed MultiPEN application
# Module: Feature Selection

if [ $# -eq 0 ]
   then
      lambda=0.0001
   else
      lambda=$1
fi

MultiPEN="MultiPEN.app/Contents/MacOS/applauncher"
OutputDirectory="ExampleOutputs/"
ExpressionData="ExampleInputs/X.txt"
Interactions="ExampleInputs/E.txt"
SampleClass="ExampleInputs/Y.txt"
FeatureNames="ExampleInputs/features.txt"
SampleNames="ExampleInputs/samples.txt"

# Run MultiPEN: feature selection 
# with default D and numIter

$MultiPEN featureSelection $OutputDirectory $ExpressionData $Interactions $SampleClass $lambda $FeatureNames $SampleNames

